# WEBP to PNG Converter

Simple one-way conversion utility for basic VP8-encoded WEBP files.